﻿using System;

namespace WindowsFormsApp4
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.radGiaiMa = new System.Windows.Forms.RadioButton();
            this.radMaHoa = new System.Windows.Forms.RadioButton();
            this.txtDuongDan = new System.Windows.Forms.TextBox();
            this.txtDuLieu = new System.Windows.Forms.TextBox();
            this.btnThucHien = new System.Windows.Forms.Button();
            this.btnTim = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 29);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(127, 16);
            this.label1.TabIndex = 0;
            this.label1.Text = "Chọn ảnh để nhúng :";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 106);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(106, 16);
            this.label2.TabIndex = 1;
            this.label2.Text = "Nội dung nhúng :";
            // 
            // radGiaiMa
            // 
            this.radGiaiMa.AutoSize = true;
            this.radGiaiMa.Location = new System.Drawing.Point(145, 163);
            this.radGiaiMa.Name = "radGiaiMa";
            this.radGiaiMa.Size = new System.Drawing.Size(74, 20);
            this.radGiaiMa.TabIndex = 1;
            this.radGiaiMa.TabStop = true;
            this.radGiaiMa.Text = "Giải mã";
            this.radGiaiMa.UseVisualStyleBackColor = true;
            // 
            // radMaHoa
            // 
            this.radMaHoa.AutoSize = true;
            this.radMaHoa.Location = new System.Drawing.Point(45, 163);
            this.radMaHoa.Name = "radMaHoa";
            this.radMaHoa.Size = new System.Drawing.Size(73, 20);
            this.radMaHoa.TabIndex = 0;
            this.radMaHoa.TabStop = true;
            this.radMaHoa.Text = "Mã hóa";
            this.radMaHoa.UseVisualStyleBackColor = true;
            // 
            // txtDuongDan
            // 
            this.txtDuongDan.Location = new System.Drawing.Point(145, 29);
            this.txtDuongDan.Name = "txtDuongDan";
            this.txtDuongDan.Size = new System.Drawing.Size(232, 22);
            this.txtDuongDan.TabIndex = 4;
            // 
            // txtDuLieu
            // 
            this.txtDuLieu.Location = new System.Drawing.Point(145, 106);
            this.txtDuLieu.Name = "txtDuLieu";
            this.txtDuLieu.Size = new System.Drawing.Size(336, 22);
            this.txtDuLieu.TabIndex = 6;
            // 
            // btnThucHien
            // 
            this.btnThucHien.Location = new System.Drawing.Point(406, 160);
            this.btnThucHien.Name = "btnThucHien";
            this.btnThucHien.Size = new System.Drawing.Size(75, 23);
            this.btnThucHien.TabIndex = 7;
            this.btnThucHien.Text = "Thực hiện";
            this.btnThucHien.UseVisualStyleBackColor = true;
            this.btnThucHien.Click += new System.EventHandler(this.btnThucHien_Click_1);
            // 
            // btnTim
            // 
            this.btnTim.Location = new System.Drawing.Point(406, 28);
            this.btnTim.Name = "btnTim";
            this.btnTim.Size = new System.Drawing.Size(75, 23);
            this.btnTim.TabIndex = 8;
            this.btnTim.Text = "Tìm";
            this.btnTim.UseVisualStyleBackColor = true;
            this.btnTim.Click += new System.EventHandler(this.btnTim_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(514, 214);
            this.Controls.Add(this.btnTim);
            this.Controls.Add(this.radGiaiMa);
            this.Controls.Add(this.btnThucHien);
            this.Controls.Add(this.radMaHoa);
            this.Controls.Add(this.txtDuLieu);
            this.Controls.Add(this.txtDuongDan);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }
        private void button1_Click(object sender, EventArgs e)
        {
            throw new NotImplementedException();
        }
        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.RadioButton radGiaiMa;
        private System.Windows.Forms.RadioButton radMaHoa;
        private System.Windows.Forms.TextBox txtDuongDan;
        private System.Windows.Forms.TextBox txtDuLieu;
        private System.Windows.Forms.Button btnThucHien;
        private System.Windows.Forms.Button btnTim;
    }
}

