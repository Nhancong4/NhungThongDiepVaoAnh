﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp4
{
    public partial class Form1 : Form
    {
        private object bit;
        private object data;
        private readonly int valueR;

        public Form1()
        {
            InitializeComponent();
        }
        private void radGiaiMa_CheckedChanged(object sender, EventArgs e)
        {
            if (radGiaiMa.Checked)
            {
                radMaHoa.Checked = false;
                txtDuLieu.ReadOnly = true;
            }
        }
        private void radMaHoa_CheckedChanged(object sender, EventArgs e)
        {
            if (radMaHoa.Checked)
            {
                radGiaiMa.Checked = false;
                txtDuLieu.ReadOnly = false;
            }
        }
        private void btnTim_Click(object sender, EventArgs e)
        {
            OpenFileDialog od = new OpenFileDialog();
            od.Filter = "Ảnh định dạng bmp (*.bmp) | *.bmp";
            od.Multiselect = false;
            if (od.ShowDialog() == DialogResult.OK)
            {
                txtDuongDan.Text = od.FileName;
            }
        }
        private void btnThucHien_Click_1(object sender, EventArgs e)
        {
            if (radMaHoa.Checked)
            {
                if (!File.Exists(txtDuongDan.Text))
                {
                    MessageBox.Show("Bạn phải chọn tệp tin ảnh");
                    btnTim.Focus();
                    return;
                }

                if (String.IsNullOrEmpty(txtDuLieu.Text))
                {
                    MessageBox.Show("Bạn phải nhập dữ liệu cần nhúng vào ảnh");
                    txtDuLieu.Focus();
                    return;
                }

                String bits = StringToBinary(txtDuLieu.Text);
                Bitmap bmp = new Bitmap(txtDuongDan.Text);
                for (int i = 0; i < bits.Length; i++)
                {
                    int x = i % bmp.Width;
                    int y = i / bmp.Width;
                    Color px = bmp.GetPixel(x, y);
                    int valueREncrypt = EncryptPixel(px.R, bits[i].ToString());
                    Color pxe = Color.FromArgb(px.A, valueREncrypt, px.G, px.B);
                    bmp.SetPixel(x, y, pxe);
                }

                // Ghi do dai chuoi vao pha R cua pixel cuoi cung 959,539-10
                int x1 = bmp.Width - 1;
                int y1 = bmp.Height - 1;
                Color px1 = bmp.GetPixel(x1, y1);
                Color pxe1 = Color.FromArgb(px1.A, txtDuLieu.Text.Length, px1.G, px1.B);
                bmp.SetPixel(x1, y1, pxe1);
                Color px2 = bmp.GetPixel(x1, y1);

                // Luu anh sau khi nhung
                SaveFileDialog sd = new SaveFileDialog();
                sd.Filter = "Ảnh định dạng bmp (*.bmp) | *.bmp";
                if (sd.ShowDialog() == DialogResult.OK)
                {
                    bmp.Save(sd.FileName);
                    txtDuLieu.Text = "";
                    txtDuongDan.Text = "";
                    bmp.Dispose();

                    Bitmap bmp1 = new Bitmap(sd.FileName);
                    Color px3 = bmp1.GetPixel(x1, y1);
                    int r = px3.R;
                }
            }
            else
            {
                // Tach du lieu ra khoi anh
                if (!File.Exists(txtDuongDan.Text))
                {
                    MessageBox.Show("Bạn phải chọn tệp tin ảnh");
                    btnTim.Focus();
                    return;
                }

                Bitmap bmp = new Bitmap(txtDuongDan.Text);
                Color px1 = bmp.GetPixel(bmp.Width - 1, bmp.Height - 1);
                int chieuDaiBit = px1.R * 8;
                String bits = "";
                for (int i = 0; i < chieuDaiBit; i++)
                {
                    int x = i % bmp.Width;
                    int y = i / bmp.Width;
                    Color px = bmp.GetPixel(x, y);
                    bits += DecryptPixel(px.R);
                }
                String duLieu = BinaryToString(bits);
                txtDuLieu.Text = duLieu;
            }
        }

        private int EncryptPixel(byte r, string v)
        {
            if (bit.Equals("0"))
            {
                if (valueR % 2 == 0)
                {
                    return valueR;
                }
                else
                {
                    return (valueR + 1) % 256;
                }
            }
            else
            {
                if (valueR % 2 == 0)
                {
                    return (valueR + 1) % 256;
                }
                else
                    return valueR;
            }
            throw new NotImplementedException();
        }

        private string DecryptPixel(byte r)
        {
            if (valueR % 2 == 0)
                return "0";
            else
                return "1";
            throw new NotImplementedException();
        }

        private string StringToBinary(string text)
        {
            StringBuilder sb = new StringBuilder();

            foreach (char c in data.ToCharArray())
            {
                sb.Append(Convert.ToString(c, 2).PadLeft(8, '0'));
            }
            return sb.ToString();
            throw new NotImplementedException();
        }

        private string BinaryToString(string bits)
        {
            List<Byte> byteList = new List<Byte>();

            for (int i = 0; i < data.Length; i += 8)
            {
                byteList.Add(Convert.ToByte(data.Substring(i, 8), 2));
            }
            return Encoding.ASCII.GetString(byteList.ToArray());
            throw new NotImplementedException();
        }
    }

}